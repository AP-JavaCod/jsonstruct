package ru.objectcat.jsonstruct.creater.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(FIELD)
public @interface FieldJSON {
	
	TypeFieldMethod method() default TypeFieldMethod.ALL;

}
