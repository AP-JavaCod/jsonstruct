module ru.objectcat.jsonstruct.create{
	
	requires transitive ru.objectcat.jsonstruct.base;
	
	exports ru.objectcat.jsonstruct.creater;
	exports ru.objectcat.jsonstruct.creater.annotation;
	
}