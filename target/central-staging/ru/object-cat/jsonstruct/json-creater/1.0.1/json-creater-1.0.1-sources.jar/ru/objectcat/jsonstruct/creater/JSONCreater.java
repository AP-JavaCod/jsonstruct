package ru.objectcat.jsonstruct.creater;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

import ru.objectcat.jsonstruct.JSONObject;
import ru.objectcat.jsonstruct.creater.annotation.ConstructorJSON;
import ru.objectcat.jsonstruct.creater.annotation.GetMethodJSON;
import ru.objectcat.jsonstruct.creater.annotation.SetMethodJSON;
import ru.objectcat.jsonstruct.creater.annotation.FieldJSON;
import ru.objectcat.jsonstruct.creater.annotation.TypeFieldMethod;

public class JSONCreater {
	
	public static JSONObject toJSON(Object object) throws IllegalAccessException, InvocationTargetException {
		JSONObject json = new JSONObject();
		getMethod(object, json);
		getField(object, json);
		return json;
	}
	
	public static void getMethod(Object object, JSONObject json) throws InvocationTargetException, IllegalAccessException {
		for(Method method : object.getClass().getDeclaredMethods()) {
			GetMethodJSON annotation = method.getAnnotation(GetMethodJSON.class);
			if(annotation != null) {
				method.setAccessible(true);
				String key = annotation.name();
				Object value = method.invoke(object);
				json.put(key, value);
			}
		}
	}
	
	public static void getField(Object object, JSONObject json) throws InvocationTargetException, IllegalAccessException {
		for(Field field: object.getClass().getDeclaredFields()) {
			FieldJSON annotation = field.getAnnotation(FieldJSON.class);
			if(annotation != null && (annotation.method() == TypeFieldMethod.GET || annotation.method() == TypeFieldMethod.ALL)) {
				field.setAccessible(true);
				String key = field.getName();
				Object value = field.get(object);
				json.put(key, value);
			}
		}
	}
	
	public static <T> T toObject(JSONObject json, Class<T> type) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		T object = instanceObject(json, type);
		setMethod(json, object);
		setField(json, object);
		return object;
	}
	
	public static <T> T instanceObjectDefault(Class<T> type) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		return type.getConstructor().newInstance();
	}
	
	public static <T> T instanceObject(JSONObject json, Class<T> type) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException  {
		for(Constructor<?> constructor : type.getConstructors()) {
			ConstructorJSON annotation = constructor.getAnnotation(ConstructorJSON.class);
			if(annotation != null) {
				Class<?>[] argumentsType = annotation.arguments();
				String[] argumentsName = annotation.names();
				Object[] values = convertArguments(json, argumentsType, argumentsName);
				return type.getConstructor(argumentsType).newInstance(values);
			}
		}
		return instanceObjectDefault(type);
	}
	
	public static void setMethod(JSONObject json, Object object) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		for(Method method : object.getClass().getDeclaredMethods()) {
			SetMethodJSON annotation = method.getAnnotation(SetMethodJSON.class);
			if(annotation != null) {
				Class<?>[] argumentsType = annotation.arguments();
				String[] argumentsName = annotation.names();
				Object[] values = convertArguments(json, argumentsType, argumentsName);
				method.setAccessible(true);
				method.invoke(object, values);
			}
		}
	}
	
	public static void setField(JSONObject json, Object object) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Class<?> type = object.getClass();
		for(Field field : type.getDeclaredFields()) {
			FieldJSON annotation = field.getAnnotation(FieldJSON.class);
			if(annotation != null && (annotation.method() == TypeFieldMethod.SET || annotation.method() == TypeFieldMethod.ALL)) {
				String key = field.getName();
				Object value = json.get(key);
				field.setAccessible(true);
				field.set(object, convertJSON(value, type));
			}
		}
	}
	
	private static Object[] convertArguments(JSONObject json, Class<?>[] types, String names[]) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		int size = types.length;
		if(size != names.length) {
			throw new RuntimeException();
		}
		Object[] values = new Object[size];
		for(int i = 0; i < size; i++) {
			Class<?> type = types[i];
			String key = names[i];
			Object value = json.get(key);
			values[i] = convertJSON(value, type);
		}
		return values;
	}
	
	private static Object convertJSON(Object value, Class<?> type) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if(value == null || type.isAssignableFrom(value.getClass()) || (Boolean.class.isAssignableFrom(value.getClass()) && type == boolean.class)) {
			return value;
		}else if(value instanceof Number n) {
			if(Byte.class.isAssignableFrom(type) || type == byte.class) {
				return n.byteValue();
			}else if(Short.class.isAssignableFrom(type) || type == short.class) {
				return n.shortValue();
			}else if(Integer.class.isAssignableFrom(type) || type == int.class) {
				return n.intValue();
			}else if(Long.class.isAssignableFrom(type) || type == long.class) {
				return n.longValue();
			}else if(Float.class.isAssignableFrom(type) || type == float.class) {
				return n.floatValue();
			}else if(Double.class.isAssignableFrom(type) || type == double.class) {
				return n.doubleValue();
			}
			throw new ClassCastException("Failed to convert JSON to object");
		}else if(value instanceof JSONObject j) {
			return toObject(j, type);
		}
		throw new ClassCastException("Failed to convert JSON to object");
	}
	
}
