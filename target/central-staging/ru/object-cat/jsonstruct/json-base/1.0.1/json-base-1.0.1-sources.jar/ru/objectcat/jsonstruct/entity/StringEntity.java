package ru.objectcat.jsonstruct.entity;

public class StringEntity implements Entity {

	
	private final String TEXT;
	private int index;
	
	public StringEntity(String text) {
		TEXT = text;
	}
	
	@Override
	public boolean isNext() {
		return index + 1 < TEXT.length();
	}
	
	@Override
	public boolean isElement() {
		return index > -1 && index < TEXT.length();
	}
	
	@Override
	public char next() {
		index++;
		return TEXT.charAt(index);
	}
	
	@Override
	public char getElement() {
		return TEXT.charAt(index);
	}
	
}
