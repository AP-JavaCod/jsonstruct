package ru.objectcat.jsonstruct.entity;

import java.io.Closeable;
import java.io.InputStream;
import java.io.IOException;

public class InputEntity implements Entity, Closeable {
	
	private final InputStream STREAM;
	
	private int nextVal;
	private int current;
	
	public InputEntity(InputStream stream) {
		STREAM = stream;
		nextVal = -1;
		current = -1;
	}
	
	@Override
	public boolean isNext() throws IOException {
		nextVal = STREAM.read();
		return nextVal > 0;
	}
	
	@Override
	public boolean isElement() {
		return current > -1;
	}
	
	@Override
	public char next() {
		current = nextVal;
		return (char)current;
	}
	
	@Override
	public char getElement() {
		return (char)current;
	}
	
	@Override
	public void close() throws IOException {
		STREAM.close();
	}

}
