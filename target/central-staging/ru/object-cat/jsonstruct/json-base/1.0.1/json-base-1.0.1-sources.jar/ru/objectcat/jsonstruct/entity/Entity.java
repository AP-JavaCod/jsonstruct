package ru.objectcat.jsonstruct.entity;

public interface Entity {
	
	boolean isNext() throws Exception;
	boolean isElement();
	
	char next();
	char getElement();

}
