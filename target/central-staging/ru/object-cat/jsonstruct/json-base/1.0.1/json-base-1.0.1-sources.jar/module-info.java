module ru.objectcat.jsonstruct.base{
	
	exports ru.objectcat.jsonstruct;
	exports ru.objectcat.jsonstruct.entity;
	
}